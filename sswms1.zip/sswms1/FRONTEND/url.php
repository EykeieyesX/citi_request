<?php
#$url = "https://schedulingandappointment.lgu2.com/backend";
$url = "http://localhost/sswms/backend";
?>