<!-- Footer -->
<style>
  main {
  margin-bottom: 50px; /* Adjust based on footer height */
}

</style>


<footer class="position-fixed bottom-0 w-100 text-center text-lg-start bg-body-tertiary">
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2025 Copyright:
    <a class="text-reset fw-bold" href="#">Social Service And Welfare Management System</a>
  </div>
</footer>
